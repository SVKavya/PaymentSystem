package com.paymentprocess.payment_process.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import com.paymentprocess.payment_process.model.CartVO;

public interface IPayment_Service {

	public JSONObject getTotalAmount(CartVO cartVo);

	public List<Map<String, Double>> finalCart(CartVO cartVO);

}
