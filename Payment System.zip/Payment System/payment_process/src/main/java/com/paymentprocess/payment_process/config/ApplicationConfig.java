package com.paymentprocess.payment_process.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties("cardtype")
@Configuration
public class ApplicationConfig {

	private String gold;
	
	private String silver;
		
	public String getGold() {
		return gold;
	}
	public void setGold(String gold) {
		this.gold = gold;
	}
	public String getSilver() {
		return silver;
	}
	public void setSilver(String silver) {
		this.silver = silver;
	}
}
