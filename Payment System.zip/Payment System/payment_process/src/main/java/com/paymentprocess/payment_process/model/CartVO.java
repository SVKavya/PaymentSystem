package com.paymentprocess.payment_process.model;

import java.util.Map;

public class CartVO {
	
	private Map<String,Double> productsCost;
	private String cardType;
	private double totalAmount;
	private boolean addOrDelete;
	
	
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public Map<String, Double> getProductsCost() {
		return productsCost;
	}
	public void setProductsCost(Map<String, Double> productsCost) {
		this.productsCost = productsCost;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public boolean isAddOrDelete() {
		return addOrDelete;
	}
	public void setAddOrDelete(boolean addOrDelete) {
		this.addOrDelete = addOrDelete;
	}
	
	
	
	
	
	

}
