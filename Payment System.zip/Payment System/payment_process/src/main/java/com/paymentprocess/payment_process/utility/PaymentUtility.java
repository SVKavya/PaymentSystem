package com.paymentprocess.payment_process.utility;

public class PaymentUtility {
	
	public double getDiscount(double amount, int discount) {
		
		double discountAmount= (amount * discount)/100;
		
		return discountAmount;
		
	}

}
