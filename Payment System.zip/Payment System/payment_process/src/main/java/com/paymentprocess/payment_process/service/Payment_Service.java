package com.paymentprocess.payment_process.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paymentprocess.payment_process.config.ApplicationConfig;
import com.paymentprocess.payment_process.constants.CardType;
import com.paymentprocess.payment_process.model.CartVO;
import com.paymentprocess.payment_process.utility.PaymentUtility;

@Service
public class Payment_Service implements IPayment_Service {

	@Autowired
	ApplicationConfig configProps;

	PaymentUtility paymentUtil = new PaymentUtility();
	List<Map<String, Double>> products = new ArrayList<>();

	@SuppressWarnings("unchecked")
	@Override
	public JSONObject getTotalAmount(CartVO cartVo) {
JSONObject totalBill = new JSONObject();
		double totalAmount = 0;
		for (Map.Entry<String, Double> product : cartVo.getProductsCost().entrySet()) {

			totalAmount = totalAmount + product.getValue();
		}

		if (cartVo.getCardType().equalsIgnoreCase(CardType.GOLD)) {

			double totalBillAmount = totalAmount
					- (paymentUtil.getDiscount(totalAmount, Integer.parseInt(configProps.getGold())));
			cartVo.setTotalAmount(totalBillAmount);
		} else if (cartVo.getCardType().equalsIgnoreCase(CardType.SILVER)) {

			double totalBillAmount = totalAmount
					- (paymentUtil.getDiscount(totalAmount, Integer.parseInt(configProps.getSilver())));
			cartVo.setTotalAmount(totalBillAmount);
		} else {

			cartVo.setTotalAmount(totalAmount);
		}

		totalBill.put("Products", cartVo.getProductsCost());
		totalBill.put("Total bill After Discount", cartVo.getTotalAmount());
		return totalBill;
	}

	@Override
	public List<Map<String, Double>> finalCart(CartVO cartVO) {
		Map<String, Double> product = new HashMap<String, Double>();
		if (cartVO.isAddOrDelete()) {
			for (Map.Entry<String, Double> map : cartVO.getProductsCost().entrySet()) {

				product.put(map.getKey(), map.getValue());
			}
			products.add(product);
		}

		else {
			try {
				String productName = null ;
				for(Map.Entry<String, Double> map : cartVO.getProductsCost().entrySet()){
					 productName = map.getKey();
					 for (Map<String, Double> mapRemove : products) {
							mapRemove.remove(productName);
					}
				}
				
			} catch (NullPointerException ex) {
				System.err.println("There is no Product in the cart so cant be deleted");
			}
		}
		return products;

	}
}