package com.paymentprocess.payment_process.constants;

public class CardType {

	public static final String GOLD = "gold";
	public static final String SILVER = "silver";

}
