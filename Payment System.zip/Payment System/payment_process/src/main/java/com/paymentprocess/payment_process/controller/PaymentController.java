package com.paymentprocess.payment_process.controller;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.paymentprocess.payment_process.model.CartVO;
import com.paymentprocess.payment_process.service.IPayment_Service;

@RestController
public class PaymentController {
	
	@Autowired
	IPayment_Service paymentService;
	
	@RequestMapping(value="/shoppingCart",method = RequestMethod.POST,consumes= "application/json", produces = "application/json")
	public ResponseEntity<List<Map<String,Double>>> shoppingCart(@RequestBody CartVO cartVO){
		
		List<Map<String,Double>> response = paymentService.finalCart(cartVO);
		return new ResponseEntity<List<Map<String,Double>>>(response,HttpStatus.OK);
		
		 
	}
	
	@RequestMapping(value="/totalPayment", method = RequestMethod.POST,consumes= "application/json", produces = "application/json")
	public ResponseEntity<JSONObject> getTotalPayment(@RequestBody CartVO cartVo){
		
		JSONObject response= paymentService.getTotalAmount(cartVo);
		return new ResponseEntity<JSONObject>(response,HttpStatus.OK);
		 
	}

}
