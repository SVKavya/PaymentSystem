package com.paymentprocess.payment_process;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentProcessApplication.class, args);
	}

}
